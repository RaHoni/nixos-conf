﻿--data.lua
require("prototypes.signals")