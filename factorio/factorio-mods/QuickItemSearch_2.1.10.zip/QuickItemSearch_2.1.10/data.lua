require("__QuickItemSearch__/prototypes/custom-input")
require("__QuickItemSearch__/prototypes/shortcut")
require("__QuickItemSearch__/prototypes/sprite")
require("__QuickItemSearch__/prototypes/style")
