global.turret_entities = nil
global.car_entities = nil