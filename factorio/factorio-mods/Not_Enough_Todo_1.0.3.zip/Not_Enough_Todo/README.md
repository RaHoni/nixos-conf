# Not-Enough-Todo

This modification is a new and improved todolist.

## Features
 - Force support
 - Multiple levels of subtasks
 - Multiplayer and Singleplayer optimized
 - Nice and fancy gui

### Credits to Firerazer for finding alot of bugs!

I have a [Discord](https://discord.gg/rVpjuh4) for discussion, etc.
If you want you can support me on [Patreon](https://www.patreon.com/LuziferSenpai).