data:extend({
  {
    type = "sprite",
    name = "qis_temporary_request",
    filename = "__QuickItemSearch__/graphics/temporary-request.png",
    size = 32,
    mipmap_count = 2,
    flags = { "gui-icon" },
  },
  {
    type = "sprite",
    name = "qis_temporary_request_disabled",
    filename = "__QuickItemSearch__/graphics/temporary-request.png",
    y = 32,
    size = 32,
    mipmap_count = 2,
    flags = { "gui-icon" },
  },
})
