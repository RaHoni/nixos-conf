require("prototypes.data")
require("prototypes.graphics")
require("prototypes.styles")
