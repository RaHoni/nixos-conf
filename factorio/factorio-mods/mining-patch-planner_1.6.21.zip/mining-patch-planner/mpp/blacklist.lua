local b = {}

b["robotMiningSite-extra"] = true
b["robotMiningSite-large"] = true
b["robotMiningSite-new"] = true
b["invisible-logistic-chest-storage"] = true
b["robot-chest-provider"] = true
b["robot-chest-requester"] = true
b["construction-recaller"] = true
b["logistic-recaller"] = true

b["se-space-elevator"] = true
b["se-space-elevator-energy-interface"] = true
b["se-space-elevator-energy-pole"] = true

b["se-spaceship-clamp"] = true
b["se-spaceship-clamp-place"] = true
b["se-spaceship-clamp-power-pole-external-east"] = true
b["se-spaceship-clamp-power-pole-external-west"] = true
b["se-spaceship-clamp-power-pole-internal"] = true

b["kr-quarry-drill"] = true

return b
