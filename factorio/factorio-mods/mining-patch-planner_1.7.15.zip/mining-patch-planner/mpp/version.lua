-- current migration version
return 010706
