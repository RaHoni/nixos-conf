# Factorio-QuickItemSearch
Factorio mod - quickly search for items in your inventory or connected logistic network.
