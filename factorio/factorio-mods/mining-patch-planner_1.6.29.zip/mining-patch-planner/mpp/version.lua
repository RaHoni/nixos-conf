-- current migration version
return 010629 -- 1.6.29
